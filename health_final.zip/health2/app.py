from flask import Flask, render_template, request, redirect, url_for
import time

app = Flask(__name__)

class HealthBot:
    def __init__(self):
        self.symptoms = {
            'diabetes': 0,
            'cardiovascular': 0
        }
        
        self.questions = [
            {
                'text': 'Do you experience frequent thirst?',
                'type': 'diabetes',
                'weight': 2
            },
            {
                'text': 'Do you experience frequent urination?',
                'type': 'diabetes',
                'weight': 2
            },
            {
                'text': 'Do you often feel fatigued or tired?',
                'type': 'both',
                'weight': 1
            },
            {
                'text': 'Have you noticed unexplained weight loss?',
                'type': 'diabetes',
                'weight': 2
            },
            {
                'text': 'Do you experience chest pain or discomfort?',
                'type': 'cardiovascular',
                'weight': 3
            },
            {
                'text': 'Do you have shortness of breath during light activities?',
                'type': 'cardiovascular',
                'weight': 2
            },
            {
                'text': 'Do you have swelling in your feet, ankles, or legs?',
                'type': 'cardiovascular',
                'weight': 2
            },
            {
                'text': 'Do you have blurred vision?',
                'type': 'diabetes',
                'weight': 1
            }
        ]

    def analyze_symptoms(self):
        """Analyze the recorded symptoms and return a diagnosis"""
        max_diabetes_score = sum(q['weight'] for q in self.questions if q['type'] in ['diabetes', 'both'])
        max_cardio_score = sum(q['weight'] for q in self.questions if q['type'] in ['cardiovascular', 'both'])
        
        diabetes_percentage = (self.symptoms['diabetes'] / max_diabetes_score) * 100
        cardio_percentage = (self.symptoms['cardiovascular'] / max_cardio_score) * 100
        
        results = []
        if diabetes_percentage >= 50:
            results.append("You are showing significant symptoms of diabetes")
        if cardio_percentage >= 50:
            results.append("You are showing significant symptoms of cardiovascular issues")
        if not results:
            results.append("Your symptoms don't strongly indicate either diabetes or cardiovascular issues")
        
        return results, diabetes_percentage, cardio_percentage

# Global variable to store the current health bot instance
health_bot = None

@app.route('/')
def index():
    global health_bot
    health_bot = HealthBot()
    return render_template('index.html', question=None, total_questions=len(health_bot.questions))

@app.route('/assess', methods=['GET', 'POST'])
def assess():
    global health_bot
    
    # If no health bot instance exists, restart
    if health_bot is None:
        return redirect(url_for('index'))
    
    # If it's the first question
    if request.method == 'GET' or 'question_index' not in request.form:
        current_index = 0
        current_question = health_bot.questions[current_index]
        return render_template('index.html', 
                               question=current_question['text'], 
                               question_index=current_index,
                               total_questions=len(health_bot.questions))
    
    # Process the answer
    current_index = int(request.form['question_index'])
    answer = request.form.get('answer') == 'yes'
    current_question = health_bot.questions[current_index]
    
    # Update symptoms based on the answer
    if answer:
        if current_question['type'] == 'both':
            health_bot.symptoms['diabetes'] += current_question['weight']
            health_bot.symptoms['cardiovascular'] += current_question['weight']
        elif current_question['type'] == 'diabetes':
            health_bot.symptoms['diabetes'] += current_question['weight']
        else:
            health_bot.symptoms['cardiovascular'] += current_question['weight']
    
    # Move to next question
    current_index += 1
    
    # If all questions are answered, analyze results
    if current_index >= len(health_bot.questions):
        results, diabetes_percentage, cardio_percentage = health_bot.analyze_symptoms()
        return render_template('results.html', 
                               results=results, 
                               diabetes_score=round(diabetes_percentage, 2),
                               cardio_score=round(cardio_percentage, 2))
    
    # Go to next question
    next_question = health_bot.questions[current_index]
    return render_template('index.html', 
                           question=next_question['text'], 
                           question_index=current_index,
                           total_questions=len(health_bot.questions))

if __name__ == '__main__':
    app.run(debug=True)