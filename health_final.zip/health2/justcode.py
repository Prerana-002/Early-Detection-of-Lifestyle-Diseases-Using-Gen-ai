import time
import sys

class HealthBot:
    def __init__(self):
        self.symptoms = {
            'diabetes': 0,
            'cardiovascular': 0
        }
        
        self.questions = [
            {
                'text': 'Do you experience frequent thirst?',
                'type': 'diabetes',
                'weight': 2
            },
            {
                'text': 'Do you experience frequent urination?',
                'type': 'diabetes',
                'weight': 2
            },
            {
                'text': 'Do you often feel fatigued or tired?',
                'type': 'both',
                'weight': 1
            },
            {
                'text': 'Have you noticed unexplained weight loss?',
                'type': 'diabetes',
                'weight': 2
            },
            {
                'text': 'Do you experience chest pain or discomfort?',
                'type': 'cardiovascular',
                'weight': 3
            },
            {
                'text': 'Do you have shortness of breath during light activities?',
                'type': 'cardiovascular',
                'weight': 2
            },
            {
                'text': 'Do you have swelling in your feet, ankles, or legs?',
                'type': 'cardiovascular',
                'weight': 2
            },
            {
                'text': 'Do you have blurred vision?',
                'type': 'diabetes',
                'weight': 1
            }
        ]

    def print_slowly(self, text):
        """Print text with a typing effect"""
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.02)
        print()

    def show_progress(self, current, total):
        """Display a simple progress bar"""
        percentage = (current / total) * 100
        bar_length = 20
        filled_length = int(bar_length * current / total)
        bar = '=' * filled_length + '-' * (bar_length - filled_length)
        print(f'\nProgress: [{bar}] {percentage:.1f}%\n')

    def get_yes_no_answer(self, question):
        """Get a valid yes/no answer from the user"""
        while True:
            answer = input(f"{question} (yes/no): ").lower().strip()
            if answer in ['yes', 'no', 'y', 'n']:
                return answer in ['yes', 'y']
            print("Please answer with 'yes' or 'no'")

    def analyze_symptoms(self):
        """Analyze the recorded symptoms and return a diagnosis"""
        max_diabetes_score = sum(q['weight'] for q in self.questions if q['type'] in ['diabetes', 'both'])
        max_cardio_score = sum(q['weight'] for q in self.questions if q['type'] in ['cardiovascular', 'both'])
        
        diabetes_percentage = (self.symptoms['diabetes'] / max_diabetes_score) * 100
        cardio_percentage = (self.symptoms['cardiovascular'] / max_cardio_score) * 100
        
        results = []
        if diabetes_percentage >= 50:
            results.append("You are showing significant symptoms of diabetes")
        if cardio_percentage >= 50:
            results.append("You are showing significant symptoms of cardiovascular issues")
        if not results:
            results.append("Your symptoms don't strongly indicate either diabetes or cardiovascular issues")
        
        return results

    def run(self):
        """Main method to run the health assessment"""
        self.print_slowly("\n=== Health Assessment Chatbot ===")
        self.print_slowly("\nHi! I'm your Health Assistant. Let's figure out how you're feeling today!")
        self.print_slowly("I will ask you a few simple questions about your symptoms to help detect whether")
        self.print_slowly("you might have cardiovascular disease or diabetes.\n")
        
        input("Press Enter to begin...")
        print("\n" + "="*50 + "\n")

        for i, question in enumerate(self.questions, 1):
            self.show_progress(i, len(self.questions))
            answer = self.get_yes_no_answer(question['text'])
            
            if answer:
                if question['type'] == 'both':
                    self.symptoms['diabetes'] += question['weight']
                    self.symptoms['cardiovascular'] += question['weight']
                elif question['type'] == 'diabetes':
                    self.symptoms['diabetes'] += question['weight']
                else:
                    self.symptoms['cardiovascular'] += question['weight']

        print("\n" + "="*50)
        self.print_slowly("\nAnalyzing your symptoms...")
        time.sleep(1)
        
        results = self.analyze_symptoms()
        print("\nAssessment Results:")
        print("-" * 20)
        for result in results:
            self.print_slowly(f"• {result}")
        
        self.print_slowly("\nIMPORTANT: This is not a medical diagnosis. Please consult a healthcare")
        self.print_slowly("professional for proper medical evaluation and diagnosis.")
        self.print_slowly("\nThank you for using the Health Assessment Chatbot!")

if __name__ == "__main__":
    bot = HealthBot()
    bot.run()